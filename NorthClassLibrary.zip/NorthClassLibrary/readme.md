﻿# Details

This class project is a base for NorthWind2020 models.