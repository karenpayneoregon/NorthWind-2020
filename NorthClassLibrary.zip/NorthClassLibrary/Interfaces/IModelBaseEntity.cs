﻿
namespace North.Interfaces
{
    public interface IModelBaseEntity
    {
        int Id { get; }
    }
}
